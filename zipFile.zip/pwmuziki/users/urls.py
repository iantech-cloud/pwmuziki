from django.contrib.auth import views as auth_views
from django.urls import path
from . import forms, views

urlpatterns = [
    path('', views.home, name='home'),
    path('photographers/<int:pk>/', views.photographer_detail, name='photographer_detail'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('photographer/dashboard/', views.photographer_dashboard, name='photographer_dashboard'),
    path('client/dashboard/', views.client_dashboard, name='client_dashboard'),
    path('dashboard/notes/new/', views.create_client_note, name='client_note_create'),
    path('dashboard/messages/<int:thread_id>/send/', views.send_message, name='message_send'),
    path('dashboard/notifications/read/', views.mark_notifications_read, name='notifications_read'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    path('register/', views.register, name='register'),
    path('register/client/', views.register_client, name='register_client'),
    path('register/photographer/', views.register_photographer, name='register_photographer'),
    path('login/', auth_views.LoginView.as_view(
        template_name='registration/login.html',
        authentication_form=forms.EmailOrUsernameAuthenticationForm,
    ), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('password-reset/', auth_views.PasswordResetView.as_view(template_name='registration/password_reset_form.html'), name='password_reset'),
    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='registration/password_reset_done.html'), name='password_reset_done'),
    path('password-reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='registration/password_reset_confirm.html'), name='password_reset_confirm'),
    path('password-reset/complete/', auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_complete.html'), name='password_reset_complete'),
]
